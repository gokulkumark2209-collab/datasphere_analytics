# DataSphere — Real-World Data Analytics Platform

A single-page, self-contained web app for domain-specific data analysis across **Finance**, **Health**, and **Retail**. Choose a domain, load a demo dataset (or upload your own CSV/Excel file), clean it, explore a tailored dashboard, build charts, train a lightweight predictive model, and generate a structured report — all in the browser.

**No backend, no build step, no data leaves your device.** Everything lives in `index.html`.

## Workflow

```
Choose Domain → Select Dataset → Clean Data → Analyze → Visualize → Predict → Generate Report
```

## Features

- **Domain selection**: Finance, Health, Retail — each with its own demo dataset and dashboard
- **Dataset upload**: CSV / `.xlsx`, drag-and-drop, or one-click demo data per domain
- **Data cleaning**: fill missing values, remove duplicates, cap outliers (IQR), label-encode categoricals, standardize numeric features — with before/after comparison
- **Domain dashboards**:
  - *Finance*: price trend, daily returns, rolling volatility, moving averages, volume, cross-asset correlation
  - *Health*: age distribution, group comparisons, indicator distributions, correlation heatmap (framed as analytical findings, never diagnoses)
  - *Retail*: revenue trend, top categories/products, sales by region, order metrics
- **General visualizations**: line, bar, pie, histogram, box, scatter, correlation heatmap — any columns
- **Predictive analytics**, implemented from scratch in JavaScript:
  - Linear Regression (normal equation, standardized features, ridge-stabilized)
  - Logistic Regression (gradient descent)
  - Decision Tree (CART, variance/Gini splitting)
  - Random Forest (bagged trees with feature subsampling)
  - Regression metrics: MAE, RMSE, R², Actual-vs-Predicted plot, feature importance
  - Classification metrics: Accuracy, Precision, Recall, F1, confusion matrix, ROC curve + AUC, feature importance
- **Automated insights**: data-driven bullets on trends, missingness, correlation, category shares, outliers, and (if trained) model performance — clearly labeled as associations/predictions, not causal or diagnostic claims
- **Report generator**: Dataset Overview, Data Quality, Key Patterns, Important Variables, Visualization Findings, Model Performance, Business/Domain Insights, Conclusion, Possible Future Analysis — exportable as PDF (via print) or standalone HTML
- **Export**: processed dataset as CSV
- Light/dark mode, responsive layout

## Running it

Just open `index.html` in a browser.

To host on GitHub Pages:

```bash
git clone <this-repo>
cd datasphere
python3 -m http.server 8000   # optional local preview
```

Enable GitHub Pages (Settings → Pages → deploy from branch) and it's live at `https://<user>.github.io/<repo>/`.

## Tech stack

- Vanilla JavaScript — no build tooling, no framework
- [Plotly.js](https://plotly.com/javascript/) for interactive charts
- [PapaParse](https://www.papaparse.com/) for CSV parsing/export
- [SheetJS (xlsx)](https://sheetjs.com/) for Excel parsing
- Google Fonts (Space Grotesk, Inter, IBM Plex Mono)

Libraries load from CDN, so an internet connection is needed the first time the page loads.

## Notes on the ML module

The regression and classification models are small, from-scratch implementations meant for **exploration and teaching**, not production use: linear/logistic regression use gradient descent or the normal equation on standardized features; the decision tree and random forest use simple CART-style splitting with a handful of candidate thresholds per feature for speed. They're a good way to see how a model behaves on a dataset instantly, in the browser, with no server round-trip — but for serious modeling, export the cleaned CSV and use pandas / scikit-learn.

## License

MIT — do whatever you'd like with it.
